﻿@echo off
chcp 65001 >nul
set "ROOT=%~dp0"
if "%~1"=="" (
  wscript //nologo "%ROOT%Запуск.vbs"
  exit /b 0
)
"%ROOT%python\python.exe" -m cdsize %*
